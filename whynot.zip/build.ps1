rm whynot.zip
7z a whynot.zip *
